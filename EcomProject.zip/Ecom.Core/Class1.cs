﻿namespace Ecom.Core
{
    public class Class1
    {

    }
}
