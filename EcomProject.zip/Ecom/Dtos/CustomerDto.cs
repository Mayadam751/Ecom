﻿namespace Ecom.Dtos
{
    public class CustomerDto
    {
        public string Name { get; set; }
        public string Password { get; set; }
        public int Age { get; set; }
    }
}
