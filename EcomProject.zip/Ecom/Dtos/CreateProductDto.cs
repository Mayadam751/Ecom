﻿namespace Ecom.Dtos
{
    public class CreateProductDto
    {
        public string Name { get; set; }
        public string Code { get; set; }
        public int Price { get; set; }

    }
}
